"""
AI Console 자동 설치 스크립트
 - Windows 전용
 - Python 3.9 이상 필요
 - Gemma 2B Q4 모델을 Hugging Face에서 자동 다운로드
"""

import os, sys, subprocess, urllib.request, platform, zipfile, venv, shutil

print("\n=== AI Console 자동 설치 시작 ===")

# USB 및 폴더 경로 설정
root_dir = os.path.dirname(os.path.abspath(__file__))
ai_dir = os.path.join(root_dir, "AI_Console")
model_dir = os.path.join(ai_dir, "model")
venv_dir = os.path.join(ai_dir, "venv")
os.makedirs(model_dir, exist_ok=True)

# 가상환경 생성
if not os.path.exists(venv_dir):
    print("[1/6] 가상환경 생성 중...")
    venv.create(venv_dir, with_pip=True)

pip = os.path.join(venv_dir, "Scripts", "pip.exe")
python = os.path.join(venv_dir, "Scripts", "python.exe")

# 필수 패키지 설치
print("[2/6] 패키지 설치 중...")
subprocess.run([pip, "install", "--upgrade", "pip"], check=True)
subprocess.run([pip, "install", "requests", "transformers", "torch", "sentencepiece"], check=True)

# 모델 다운로드 (Gemma 2B Q4 GGUF 예시)
print("[3/6] 모델 다운로드 중 (약 2.6GB)...")
model_url = "https://huggingface.co/bartowski/gemma-2b-it-GGUF/resolve/main/gemma-2b-it.Q4_K_M.gguf"
model_path = os.path.join(model_dir, "gemma-2b-it.Q4_K_M.gguf")

if not os.path.exists(model_path):
    urllib.request.urlretrieve(model_url, model_path)
    print("모델 다운로드 완료.")
else:
    print("모델이 이미 존재함. 건너뜀.")

# main.py 생성
print("[4/6] main.py 생성 중...")
main_py = r'''# main.py
import os, sys, json, torch
from transformers import AutoTokenizer, AutoModelForCausalLM

commands = ["/xknow", "/pars", "/namu", "/offi", "/now", "/math", "/sci"]
print("🧠 AI Console Loaded")
print("Available commands:", ", ".join(commands))
print("Type /exit to quit.\n")

tokenizer = None
model = None

def load_model():
    global tokenizer, model
    print("모델 로딩 중... (약간의 시간이 걸립니다)")
    tokenizer = AutoTokenizer.from_pretrained("google/gemma-2b-it", trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained("google/gemma-2b-it", torch_dtype=torch.float16, device_map="auto")
    print("✅ 모델 로딩 완료!\n")

load_model()

while True:
    user = input("You > ").strip()
    if user == "/exit":
        print("Goodbye!")
        break
    elif user.startswith("/"):
        print(f"[Command Detected] {user}")
        continue
    else:
        inputs = tokenizer(user, return_tensors="pt").to(model.device)
        outputs = model.generate(**inputs, max_new_tokens=150)
        text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        print("🤖", text)
'''

with open(os.path.join(ai_dir, "main.py"), "w", encoding="utf-8") as f:
    f.write(main_py)

# 실행 배치파일 생성
print("[5/6] 실행용 run_ai.bat 생성 중...")
run_bat = os.path.join(ai_dir, "run_ai.bat")
with open(run_bat, "w", encoding="utf-8") as f:
    f.write(f'@echo off\ncd /d "%~dp0"\n"{python}" main.py\npause\n')

print("[6/6] 설치 완료 ✅")
print(f"\n폴더: {ai_dir}")
print("이제 인터넷 없는 곳에서도 'run_ai.bat' 더블클릭으로 실행 가능.")